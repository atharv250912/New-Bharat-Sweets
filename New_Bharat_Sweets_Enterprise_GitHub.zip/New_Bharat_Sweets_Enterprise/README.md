# New Bharat Sweets Enterprise Shop OS

A modular Python + HTML + CSS web application using Flask and SQLite.

## Included modules
- Private password-protected dashboard and responsive UI
- Product catalogue, categories, SKUs, pricing, cost, tax and stock thresholds
- Multi-item sales invoices with proportional invoice discount and product tax calculations
- Automatic finished-product stock deduction and printable invoices
- Customer directory, loyalty points and spend tracking
- Supplier directory and purchase receiving for products / ingredients
- Ingredient inventory, recipe/BOM setup and production batches
- Production completion consumes recipe ingredients and adds finished stock
- Manual inventory adjustments and stock movement audit trail
- Festival and local-event calendar with configurable demand-uplift assumptions
- Daily context diary for weather, footfall and local events
- Explainable demand-planning baseline using recent sales, weekday patterns, festival uplift and footfall
- Expenses, sales reports, management margin estimates and CSV exports
- Product CSV import, database backup download and shop settings

## Local setup (Mac)
```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
export APP_PASSWORD='choose-a-strong-private-password'
export SECRET_KEY='set-a-long-random-secret'
python3 app.py
```
Open http://127.0.0.1:5000

## GitHub + Render deployment
1. Create a private GitHub repository.
2. Upload the contents of this folder to the repository root.
3. In Render, choose New → Blueprint and connect the repository.
4. Set a strong APP_PASSWORD. Render generates SECRET_KEY.
5. Deploy. The included blueprint configures a persistent disk at /var/data.

Persistent storage may require a paid hosting plan; check the provider's current pricing and policies. Never commit passwords, database files or secrets to GitHub.

## Important operational notes
- The app starts with an empty database; no fabricated transactions or products are seeded.
- Festival dates are planning prompts and must be verified annually against official calendars and local observances.
- Festival uplift percentages are user assumptions, not guaranteed demand.
- Forecasts are simple, explainable heuristics. They are not a validated machine-learning model. Build at least 8–12 weeks of clean sales history before relying on forecasts.
- Ingredient consumption happens when production batches are completed. Selling finished stock only deducts finished product stock, avoiding double consumption.
- Purchase receiving supports one item per record. Repeat the supplier invoice reference for multi-line supplier bills.
- Recipe quantities must be entered using consistent units and carefully checked.
- Expiry/lot tracking is not fully implemented. Maintain physical food-safety and expiry controls.
- GST treatment, tax invoices and accounting compliance must be reviewed with a qualified accountant before live use.
- This is a strong operational starter, not a certified POS/accounting system. Test it and reconcile with your existing billing records and physical stock before depending on it.

## Run business-logic tests

```bash
python3 -m unittest discover -s tests -v
```

The included suite covers invoice arithmetic, discount allocation, contribution margin, break-even, stock cover, reorder calculations, festival multipliers, forecast baselines and inventory movements.
