import os
import io
import csv
import json
import sqlite3
import secrets
import hashlib
from datetime import datetime, date, timedelta
from functools import wraps
from pathlib import Path
from collections import defaultdict

from flask import (
    Flask, request, redirect, url_for, session, flash, render_template,
    Response, jsonify, abort, send_file
)

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = Path(os.environ.get("DATABASE_PATH", BASE_DIR / "instance" / "new_bharat_sweets.db"))
APP_PASSWORD = os.environ.get("APP_PASSWORD", "")
SECRET_KEY = os.environ.get("SECRET_KEY", "development-only-change-this")
CURRENCY = os.environ.get("CURRENCY", "INR")
SHOP_NAME = os.environ.get("SHOP_NAME", "New Bharat Sweets")
SHOP_CITY = os.environ.get("SHOP_CITY", "Raipur, Chhattisgarh")

app = Flask(__name__)
app.secret_key = SECRET_KEY
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("COOKIE_SECURE", "0") == "1",
    MAX_CONTENT_LENGTH=8 * 1024 * 1024,
)

SCHEMA = """
CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY, value TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE,
    description TEXT DEFAULT '', active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    sku TEXT UNIQUE, name TEXT NOT NULL COLLATE NOCASE UNIQUE,
    category_id INTEGER REFERENCES categories(id),
    description TEXT DEFAULT '', unit TEXT NOT NULL DEFAULT 'kg',
    selling_price REAL NOT NULL DEFAULT 0 CHECK(selling_price >= 0),
    cost_price REAL NOT NULL DEFAULT 0 CHECK(cost_price >= 0),
    tax_rate REAL NOT NULL DEFAULT 0 CHECK(tax_rate >= 0),
    stock REAL NOT NULL DEFAULT 0 CHECK(stock >= 0),
    reorder_level REAL NOT NULL DEFAULT 0 CHECK(reorder_level >= 0),
    target_stock REAL NOT NULL DEFAULT 0,
    shelf_life_days INTEGER DEFAULT 0,
    is_perishable INTEGER DEFAULT 0,
    active INTEGER DEFAULT 1,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT, customer_code TEXT UNIQUE,
    name TEXT NOT NULL, phone TEXT DEFAULT '', email TEXT DEFAULT '',
    birthday TEXT DEFAULT '', address TEXT DEFAULT '', notes TEXT DEFAULT '',
    points INTEGER DEFAULT 0, total_spend REAL DEFAULT 0,
    created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS suppliers (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    contact_person TEXT DEFAULT '', phone TEXT DEFAULT '', email TEXT DEFAULT '',
    address TEXT DEFAULT '', notes TEXT DEFAULT '', active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS ingredients (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL UNIQUE,
    unit TEXT NOT NULL DEFAULT 'kg', cost_per_unit REAL NOT NULL DEFAULT 0,
    stock REAL NOT NULL DEFAULT 0, reorder_level REAL NOT NULL DEFAULT 0,
    supplier_id INTEGER REFERENCES suppliers(id), notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS recipes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    product_id INTEGER NOT NULL REFERENCES products(id),
    ingredient_id INTEGER NOT NULL REFERENCES ingredients(id),
    quantity REAL NOT NULL CHECK(quantity >= 0),
    UNIQUE(product_id, ingredient_id)
);
CREATE TABLE IF NOT EXISTS purchases (
    id INTEGER PRIMARY KEY AUTOINCREMENT, supplier_id INTEGER REFERENCES suppliers(id),
    invoice_number TEXT DEFAULT '', purchase_date TEXT NOT NULL,
    subtotal REAL NOT NULL DEFAULT 0, tax REAL NOT NULL DEFAULT 0,
    total REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'Received',
    notes TEXT DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS purchase_lines (
    id INTEGER PRIMARY KEY AUTOINCREMENT, purchase_id INTEGER NOT NULL REFERENCES purchases(id),
    item_type TEXT NOT NULL, item_id INTEGER NOT NULL,
    item_name TEXT NOT NULL, quantity REAL NOT NULL, unit_cost REAL NOT NULL,
    line_total REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS sales (
    id INTEGER PRIMARY KEY AUTOINCREMENT, invoice_no TEXT UNIQUE NOT NULL,
    customer_id INTEGER REFERENCES customers(id),
    sale_date TEXT NOT NULL, subtotal REAL NOT NULL, discount REAL NOT NULL DEFAULT 0,
    tax REAL NOT NULL DEFAULT 0, total REAL NOT NULL, payment_method TEXT NOT NULL,
    channel TEXT NOT NULL DEFAULT 'Walk-in', status TEXT NOT NULL DEFAULT 'Completed',
    notes TEXT DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS sale_lines (
    id INTEGER PRIMARY KEY AUTOINCREMENT, sale_id INTEGER NOT NULL REFERENCES sales(id),
    product_id INTEGER NOT NULL REFERENCES products(id), product_name TEXT NOT NULL,
    quantity REAL NOT NULL, unit_price REAL NOT NULL, cost_price REAL NOT NULL,
    discount REAL NOT NULL DEFAULT 0, tax_rate REAL NOT NULL DEFAULT 0,
    line_total REAL NOT NULL
);
CREATE TABLE IF NOT EXISTS expenses (
    id INTEGER PRIMARY KEY AUTOINCREMENT, expense_date TEXT NOT NULL,
    category TEXT NOT NULL, description TEXT DEFAULT '', amount REAL NOT NULL,
    payment_method TEXT DEFAULT 'Cash', recurring INTEGER DEFAULT 0
);
CREATE TABLE IF NOT EXISTS stock_movements (
    id INTEGER PRIMARY KEY AUTOINCREMENT, item_type TEXT NOT NULL,
    item_id INTEGER NOT NULL, item_name TEXT NOT NULL, movement_type TEXT NOT NULL,
    quantity REAL NOT NULL, unit TEXT NOT NULL, reference TEXT DEFAULT '',
    notes TEXT DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS festivals (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL,
    event_date TEXT NOT NULL, end_date TEXT DEFAULT '', category TEXT DEFAULT 'Festival',
    expected_uplift REAL NOT NULL DEFAULT 0, preparation_days INTEGER DEFAULT 7,
    notes TEXT DEFAULT '', active INTEGER DEFAULT 1
);
CREATE TABLE IF NOT EXISTS daily_context (
    id INTEGER PRIMARY KEY AUTOINCREMENT, context_date TEXT NOT NULL UNIQUE,
    weekday_type TEXT DEFAULT 'Normal', weather TEXT DEFAULT 'Unknown',
    temperature REAL, rainfall_mm REAL, local_event TEXT DEFAULT '',
    footfall_index REAL DEFAULT 1, notes TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS production_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL REFERENCES products(id),
    planned_date TEXT NOT NULL, planned_quantity REAL NOT NULL,
    actual_quantity REAL DEFAULT 0, status TEXT DEFAULT 'Planned',
    notes TEXT DEFAULT '', created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS stock_lots (
    id INTEGER PRIMARY KEY AUTOINCREMENT, product_id INTEGER NOT NULL REFERENCES products(id),
    received_date TEXT NOT NULL, expiry_date TEXT DEFAULT '', quantity_received REAL NOT NULL,
    quantity_remaining REAL NOT NULL, unit_cost REAL DEFAULT 0, source TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT, actor TEXT NOT NULL,
    action TEXT NOT NULL, entity TEXT NOT NULL, entity_id INTEGER,
    detail TEXT DEFAULT '', created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_sales_date ON sales(sale_date);
CREATE INDEX IF NOT EXISTS idx_sale_lines_product ON sale_lines(product_id);
CREATE INDEX IF NOT EXISTS idx_stock_movement_date ON stock_movements(created_at);
CREATE INDEX IF NOT EXISTS idx_festivals_date ON festivals(event_date);
"""

def db():
    DB_PATH.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(DB_PATH, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA foreign_keys=ON")
    con.execute("PRAGMA journal_mode=WAL")
    return con

def now_iso():
    return datetime.now().isoformat(timespec="seconds")

def init_db():
    with db() as con:
        con.executescript(SCHEMA)
        defaults = {
            "shop_name": SHOP_NAME, "shop_city": SHOP_CITY,
            "gstin": "", "phone": "", "address": "",
            "loyalty_points_per_100": "1", "low_stock_email": "",
            "forecast_horizon": "14", "default_tax_rate": "0",
        }
        for key, value in defaults.items():
            con.execute("INSERT OR IGNORE INTO settings(key,value) VALUES(?,?)", (key, value))
        for name, description in [
            ("Sweets", "Traditional and contemporary sweets"),
            ("Namkeen", "Savory snacks and mixtures"),
            ("Snacks", "Packaged and ready-to-eat snacks"),
            ("Beverages", "Drinks and refreshments"),
            ("Other", "Other shop products"),
        ]:
            con.execute("INSERT OR IGNORE INTO categories(name,description) VALUES(?,?)", (name, description))

def setting(key, default=""):
    with db() as con:
        row = con.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        return row["value"] if row else default

def audit(action, entity, entity_id=None, detail=""):
    with db() as con:
        con.execute(
            "INSERT INTO audit_log(actor,action,entity,entity_id,detail,created_at) VALUES(?,?,?,?,?,?)",
            (session.get("username", "owner"), action, entity, entity_id, detail[:1000], now_iso())
        )

def money(value):
    return f"₹{float(value or 0):,.2f}"

app.jinja_env.filters["money"] = money
app.jinja_env.filters["num"] = lambda x: f"{float(x or 0):,.2f}"

def login_required(fn):
    @wraps(fn)
    def wrapper(*args, **kwargs):
        if not APP_PASSWORD:
            return render_template("setup.html"), 503
        if not session.get("authenticated"):
            return redirect(url_for("login", next=request.path))
        return fn(*args, **kwargs)
    return wrapper

@app.context_processor
def inject_globals():
    return {
        "shop_name": setting("shop_name", SHOP_NAME),
        "shop_city": setting("shop_city", SHOP_CITY),
        "today_label": date.today().strftime("%A, %d %B %Y"),
        "current_year": date.today().year,
        "today_iso": date.today().isoformat(),
        "setting_address": setting("address", ""),
    }

@app.before_request
def csrf_guard():
    if request.method == "POST" and session.get("authenticated"):
        token = session.get("csrf_token", "")
        supplied = request.form.get("_csrf", "")
        if not token or not secrets.compare_digest(token, supplied):
            abort(400, "Your session token expired. Refresh the page and try again.")

@app.context_processor
def inject_csrf():
    if session.get("authenticated") and not session.get("csrf_token"):
        session["csrf_token"] = secrets.token_urlsafe(24)
    return {"csrf_token": session.get("csrf_token", "")}

def record_movement(con, item_type, item_id, item_name, kind, qty, unit, reference="", notes=""):
    con.execute(
        """INSERT INTO stock_movements(item_type,item_id,item_name,movement_type,quantity,unit,
           reference,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?)""",
        (item_type, item_id, item_name, kind, qty, unit, reference, notes, now_iso())
    )

def next_invoice(con):
    prefix = date.today().strftime("NBS%y%m%d")
    row = con.execute("SELECT COUNT(*) n FROM sales WHERE invoice_no LIKE ?", (prefix + "-%",)).fetchone()
    return f"{prefix}-{int(row['n'])+1:04d}"

def parse_float(form, key, default=0.0):
    raw = form.get(key, "")
    value = default if raw in (None, "") else float(raw)
    if value < 0:
        raise ValueError(f"{key.replace('_',' ').title()} cannot be negative.")
    return value

def get_product_rows(active=True):
    with db() as con:
        query = """SELECT p.*,c.name category FROM products p LEFT JOIN categories c
                   ON c.id=p.category_id"""
        if active:
            query += " WHERE p.active=1"
        return con.execute(query + " ORDER BY p.name").fetchall()

init_db()

@app.route("/login", methods=["GET", "POST"])
def login():
    if not APP_PASSWORD:
        return render_template("setup.html"), 503
    if request.method == "POST":
        if secrets.compare_digest(request.form.get("password", ""), APP_PASSWORD):
            session.clear()
            session["authenticated"] = True
            session["username"] = "owner"
            session["csrf_token"] = secrets.token_urlsafe(24)
            return redirect(request.args.get("next") or url_for("dashboard"))
        flash("Incorrect password.", "error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def dashboard():
    today = date.today().isoformat()
    month_start = date.today().replace(day=1).isoformat()
    with db() as con:
        day = con.execute(
            "SELECT COALESCE(SUM(total),0) revenue,COUNT(*) invoices FROM sales WHERE date(sale_date)=?",
            (today,)
        ).fetchone()
        month = con.execute(
            """SELECT COALESCE(SUM(total),0) revenue,COALESCE(SUM(discount),0) discounts,
               COALESCE(SUM(tax),0) tax,COUNT(*) invoices FROM sales WHERE date(sale_date)>=?""",
            (month_start,)
        ).fetchone()
        cost = con.execute(
            """SELECT COALESCE(SUM(sl.quantity*sl.cost_price),0) cost
               FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id WHERE date(s.sale_date)>=?""",
            (month_start,)
        ).fetchone()["cost"]
        expenses = con.execute(
            "SELECT COALESCE(SUM(amount),0) total FROM expenses WHERE date(expense_date)>=?",
            (month_start,)
        ).fetchone()["total"]
        products = con.execute("SELECT COUNT(*) n FROM products WHERE active=1").fetchone()["n"]
        low = con.execute(
            """SELECT p.*,c.name category FROM products p LEFT JOIN categories c ON c.id=p.category_id
               WHERE p.active=1 AND p.stock<=p.reorder_level ORDER BY p.stock LIMIT 8"""
        ).fetchall()
        recent = con.execute("SELECT * FROM sales ORDER BY id DESC LIMIT 8").fetchall()
        best = con.execute(
            """SELECT product_name,SUM(quantity) qty,SUM(line_total) revenue
               FROM sale_lines GROUP BY product_id ORDER BY qty DESC LIMIT 5"""
        ).fetchall()
        trend = con.execute(
            """SELECT date(sale_date) day,SUM(total) revenue FROM sales
               WHERE date(sale_date)>=date('now','-13 days','localtime')
               GROUP BY date(sale_date) ORDER BY day"""
        ).fetchall()
        upcoming = con.execute(
            """SELECT * FROM festivals WHERE active=1 AND date(event_date)>=date('now')
               ORDER BY event_date LIMIT 5"""
        ).fetchall()
    trend_map = {r["day"]: float(r["revenue"]) for r in trend}
    labels, values = [], []
    for i in range(13, -1, -1):
        d = date.today() - timedelta(days=i)
        labels.append(d.strftime("%d %b"))
        values.append(trend_map.get(d.isoformat(), 0))
    gross_profit = float(month["revenue"]) - float(cost)
    return render_template(
        "dashboard.html", day=day, month=month, cost=cost, expenses=expenses,
        gross_profit=gross_profit, net_estimate=gross_profit-expenses,
        products=products, low=low, recent=recent, best=best, festivals=upcoming,
        chart_labels=labels, chart_values=values
    )

@app.route("/products", methods=["GET", "POST"])
@login_required
def products():
    if request.method == "POST":
        try:
            name = request.form["name"].strip()
            sku = request.form.get("sku", "").strip() or None
            category_id = int(request.form["category_id"])
            unit = request.form["unit"].strip()
            price = parse_float(request.form, "selling_price")
            cost = parse_float(request.form, "cost_price")
            tax = parse_float(request.form, "tax_rate")
            stock = parse_float(request.form, "opening_stock")
            reorder = parse_float(request.form, "reorder_level")
            target = parse_float(request.form, "target_stock")
            shelf = int(request.form.get("shelf_life_days") or 0)
            if not name or not unit or shelf < 0:
                raise ValueError("Enter a name, unit and valid shelf life.")
            with db() as con:
                cur = con.execute(
                    """INSERT INTO products(sku,name,category_id,unit,selling_price,cost_price,
                       tax_rate,stock,reorder_level,target_stock,shelf_life_days,is_perishable,created_at)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (sku,name,category_id,unit,price,cost,tax,stock,reorder,target,shelf,
                     int(request.form.get("is_perishable")=="on"),now_iso())
                )
                if stock:
                    record_movement(con,"product",cur.lastrowid,name,"Opening stock",stock,unit,"Initial setup")
            audit("CREATE","product",cur.lastrowid,name)
            flash(f"{name} added to catalogue.", "success")
        except sqlite3.IntegrityError:
            flash("Product name or SKU already exists.", "error")
        except (ValueError, KeyError) as exc:
            flash(str(exc), "error")
        return redirect(url_for("products"))
    with db() as con:
        categories = con.execute("SELECT * FROM categories WHERE active=1 ORDER BY name").fetchall()
        rows = con.execute(
            """SELECT p.*,c.name category FROM products p LEFT JOIN categories c
               ON c.id=p.category_id WHERE p.active=1 ORDER BY c.name,p.name"""
        ).fetchall()
    return render_template("products.html", categories=categories, products=rows)

@app.route("/products/<int:pid>/update", methods=["POST"])
@login_required
def product_update(pid):
    try:
        with db() as con:
            p = con.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
            if not p: abort(404)
            con.execute(
                """UPDATE products SET name=?,sku=?,selling_price=?,cost_price=?,tax_rate=?,
                   reorder_level=?,target_stock=?,shelf_life_days=? WHERE id=?""",
                (request.form["name"].strip(),request.form.get("sku") or None,
                 parse_float(request.form,"selling_price"),parse_float(request.form,"cost_price"),
                 parse_float(request.form,"tax_rate"),parse_float(request.form,"reorder_level"),
                 parse_float(request.form,"target_stock"),int(request.form.get("shelf_life_days") or 0),pid)
            )
        audit("UPDATE","product",pid,"Product details edited")
        flash("Product updated.", "success")
    except (ValueError, KeyError, sqlite3.IntegrityError) as exc:
        flash(str(exc) or "Unable to update product.", "error")
    return redirect(url_for("products"))

@app.route("/products/<int:pid>/archive", methods=["POST"])
@login_required
def product_archive(pid):
    with db() as con:
        con.execute("UPDATE products SET active=0 WHERE id=?", (pid,))
    audit("ARCHIVE","product",pid)
    flash("Product archived; historical sales remain.", "success")
    return redirect(url_for("products"))

@app.route("/categories", methods=["GET","POST"])
@login_required
def categories():
    if request.method == "POST":
        name=request.form.get("name","").strip()
        if name:
            try:
                with db() as con: con.execute("INSERT INTO categories(name,description) VALUES(?,?)",(name,request.form.get("description","")))
                flash("Category added.","success")
            except sqlite3.IntegrityError: flash("Category already exists.","error")
        return redirect(url_for("categories"))
    with db() as con: rows=con.execute("SELECT * FROM categories ORDER BY name").fetchall()
    return render_template("categories.html",categories=rows)

@app.route("/customers", methods=["GET","POST"])
@login_required
def customers():
    if request.method=="POST":
        try:
            name=request.form["name"].strip()
            if not name: raise ValueError("Customer name is required.")
            code=request.form.get("customer_code","").strip() or None
            with db() as con:
                con.execute(
                    """INSERT INTO customers(customer_code,name,phone,email,birthday,address,notes,created_at)
                       VALUES(?,?,?,?,?,?,?,?)""",
                    (code,name,request.form.get("phone","").strip(),request.form.get("email","").strip(),
                     request.form.get("birthday",""),request.form.get("address",""),request.form.get("notes",""),now_iso())
                )
            flash("Customer added.","success")
        except (ValueError,sqlite3.IntegrityError) as exc: flash(str(exc),"error")
        return redirect(url_for("customers"))
    q=request.args.get("q","").strip()
    with db() as con:
        rows=con.execute(
            """SELECT * FROM customers WHERE name LIKE ? OR phone LIKE ? OR customer_code LIKE ?
               ORDER BY name LIMIT 250""",(f"%{q}%",f"%{q}%",f"%{q}%")
        ).fetchall()
    return render_template("customers.html",customers=rows,q=q)

@app.route("/suppliers", methods=["GET","POST"])
@login_required
def suppliers():
    if request.method=="POST":
        name=request.form.get("name","").strip()
        if name:
            with db() as con:
                con.execute("INSERT INTO suppliers(name,contact_person,phone,email,address,notes) VALUES(?,?,?,?,?,?)",
                            (name,request.form.get("contact_person",""),request.form.get("phone",""),
                             request.form.get("email",""),request.form.get("address",""),request.form.get("notes","")))
            flash("Supplier added.","success")
        return redirect(url_for("suppliers"))
    with db() as con: rows=con.execute("SELECT * FROM suppliers WHERE active=1 ORDER BY name").fetchall()
    return render_template("suppliers.html",suppliers=rows)

@app.route("/ingredients", methods=["GET","POST"])
@login_required
def ingredients():
    if request.method=="POST":
        try:
            name=request.form["name"].strip(); unit=request.form.get("unit","kg")
            cost=parse_float(request.form,"cost_per_unit"); stock=parse_float(request.form,"stock")
            reorder=parse_float(request.form,"reorder_level")
            supplier=int(request.form["supplier_id"]) if request.form.get("supplier_id") else None
            with db() as con:
                cur=con.execute(
                    "INSERT INTO ingredients(name,unit,cost_per_unit,stock,reorder_level,supplier_id,notes) VALUES(?,?,?,?,?,?,?)",
                    (name,unit,cost,stock,reorder,supplier,request.form.get("notes",""))
                )
                if stock: record_movement(con,"ingredient",cur.lastrowid,name,"Opening stock",stock,unit,"Initial setup")
            flash("Ingredient added.","success")
        except (ValueError,KeyError,sqlite3.IntegrityError) as exc: flash(str(exc),"error")
        return redirect(url_for("ingredients"))
    with db() as con:
        rows=con.execute("SELECT i.*,s.name supplier FROM ingredients i LEFT JOIN suppliers s ON s.id=i.supplier_id ORDER BY i.name").fetchall()
        suppliers=con.execute("SELECT * FROM suppliers WHERE active=1 ORDER BY name").fetchall()
    return render_template("ingredients.html",ingredients=rows,suppliers=suppliers)

@app.route("/recipes", methods=["GET","POST"])
@login_required
def recipes():
    if request.method=="POST":
        try:
            product_id=int(request.form["product_id"]); ingredient_id=int(request.form["ingredient_id"])
            qty=parse_float(request.form,"quantity")
            with db() as con:
                con.execute(
                    """INSERT INTO recipes(product_id,ingredient_id,quantity) VALUES(?,?,?)
                       ON CONFLICT(product_id,ingredient_id) DO UPDATE SET quantity=excluded.quantity""",
                    (product_id,ingredient_id,qty)
                )
            flash("Recipe quantity saved per one product unit.","success")
        except (ValueError,KeyError,sqlite3.IntegrityError) as exc: flash(str(exc),"error")
        return redirect(url_for("recipes"))
    with db() as con:
        products=con.execute("SELECT * FROM products WHERE active=1 ORDER BY name").fetchall()
        ingredients=con.execute("SELECT * FROM ingredients ORDER BY name").fetchall()
        rows=con.execute(
            """SELECT r.*,p.name product,i.name ingredient,i.unit FROM recipes r
               JOIN products p ON p.id=r.product_id JOIN ingredients i ON i.id=r.ingredient_id
               ORDER BY p.name,i.name"""
        ).fetchall()
    return render_template("recipes.html",products=products,ingredients=ingredients,recipes=rows)


@app.route("/inventory", methods=["GET","POST"])
@login_required
def inventory():
    if request.method == "POST":
        try:
            kind = request.form.get("item_type", "product")
            item_id = int(request.form["item_id"])
            change = float(request.form["quantity"])
            reason = request.form.get("reason", "").strip()
            if change == 0:
                raise ValueError("Quantity adjustment cannot be zero.")
            table = "products" if kind == "product" else "ingredients"
            with db() as con:
                item = con.execute(f"SELECT * FROM {table} WHERE id=?", (item_id,)).fetchone()
                if not item:
                    raise ValueError("Selected item was not found.")
                updated = float(item["stock"]) + change
                if updated < 0:
                    raise ValueError("Adjustment would make stock negative.")
                con.execute(f"UPDATE {table} SET stock=? WHERE id=?", (updated, item_id))
                record_movement(con, kind, item_id, item["name"], "Manual adjustment",
                                change, item["unit"], "", reason)
            audit("ADJUST", kind, item_id, f"{change:+g} {item['unit']} · {reason}")
            flash("Stock adjustment saved.", "success")
        except (ValueError, KeyError) as exc:
            flash(str(exc), "error")
        return redirect(url_for("inventory"))
    with db() as con:
        products = con.execute(
            """SELECT p.*,c.name category FROM products p LEFT JOIN categories c
               ON c.id=p.category_id WHERE p.active=1 ORDER BY p.name"""
        ).fetchall()
        ingredients = con.execute("SELECT * FROM ingredients ORDER BY name").fetchall()
        movements = con.execute("SELECT * FROM stock_movements ORDER BY id DESC LIMIT 100").fetchall()
    return render_template("inventory.html", products=products, ingredients=ingredients, movements=movements)

@app.route("/purchases", methods=["GET","POST"])
@login_required
def purchases():
    if request.method=="POST":
        try:
            supplier_id=int(request.form["supplier_id"]) if request.form.get("supplier_id") else None
            kind=request.form["item_type"]; item_id=int(request.form["item_id"])
            qty=parse_float(request.form,"quantity"); unit_cost=parse_float(request.form,"unit_cost")
            if qty<=0: raise ValueError("Quantity must be greater than zero.")
            with db() as con:
                table="products" if kind=="product" else "ingredients"
                item=con.execute(f"SELECT * FROM {table} WHERE id=?",(item_id,)).fetchone()
                if not item: raise ValueError("Selected item was not found.")
                name=item["name"]; unit=item["unit"]; total=qty*unit_cost
                cur=con.execute(
                    """INSERT INTO purchases(supplier_id,invoice_number,purchase_date,subtotal,total,notes,created_at)
                       VALUES(?,?,?,?,?,?,?)""",
                    (supplier_id,request.form.get("invoice_number",""),request.form.get("purchase_date") or date.today().isoformat(),
                     total,total,request.form.get("notes",""),now_iso())
                )
                con.execute(
                    """INSERT INTO purchase_lines(purchase_id,item_type,item_id,item_name,quantity,unit_cost,line_total)
                       VALUES(?,?,?,?,?,?,?)""",(cur.lastrowid,kind,item_id,name,qty,unit_cost,total)
                )
                con.execute(f"UPDATE {table} SET stock=stock+? WHERE id=?",(qty,item_id))
                record_movement(con,kind,item_id,name,"Purchase received",qty,unit,f"PO-{cur.lastrowid}",request.form.get("notes",""))
            flash("Purchase received and stock increased.","success")
        except (ValueError,KeyError) as exc: flash(str(exc),"error")
        return redirect(url_for("purchases"))
    with db() as con:
        suppliers=con.execute("SELECT * FROM suppliers WHERE active=1 ORDER BY name").fetchall()
        products=con.execute("SELECT id,name,unit FROM products WHERE active=1 ORDER BY name").fetchall()
        ingredients=con.execute("SELECT id,name,unit FROM ingredients ORDER BY name").fetchall()
        rows=con.execute(
            """SELECT p.*,s.name supplier FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id
               ORDER BY p.id DESC LIMIT 50"""
        ).fetchall()
    return render_template("purchases.html",suppliers=suppliers,products=products,ingredients=ingredients,purchases=rows)

@app.route("/sales", methods=["GET","POST"])
@login_required
def sales():
    if request.method=="POST":
        try:
            customer_id=int(request.form["customer_id"]) if request.form.get("customer_id") else None
            ids=request.form.getlist("product_id[]"); quantities=request.form.getlist("quantity[]")
            if not ids: raise ValueError("Add at least one product line.")
            discount=parse_float(request.form,"discount")
            payment=request.form.get("payment_method","Cash"); channel=request.form.get("channel","Walk-in")
            line_items=[]
            subtotal=0; total_tax=0; cost_total=0
            requested_by_product = {}
            for raw_id, raw_qty in zip(ids, quantities):
                pid_check = int(raw_id)
                requested_by_product[pid_check] = requested_by_product.get(pid_check, 0) + float(raw_qty)
            with db() as con:
                for raw_id,raw_qty in zip(ids,quantities):
                    pid=int(raw_id); qty=float(raw_qty)
                    if qty<=0: raise ValueError("Each quantity must be positive.")
                    p=con.execute("SELECT * FROM products WHERE id=? AND active=1",(pid,)).fetchone()
                    if not p: raise ValueError("A selected product is unavailable.")
                    if requested_by_product[pid] > p["stock"]:
                        raise ValueError(f"Insufficient combined quantity for {p['name']} ({p['stock']:g} {p['unit']} available).")
                    line=qty*p["selling_price"]
                    subtotal+=line;cost_total+=qty*p["cost_price"]
                    line_items.append((p,qty,line))
                if discount>subtotal: raise ValueError("Discount cannot exceed subtotal.")
                for p, qty, line in line_items:
                    allocated_discount = discount * (line / subtotal) if subtotal else 0
                    total_tax += (line - allocated_discount) * p["tax_rate"] / 100
                total=subtotal-discount+total_tax
                invoice=next_invoice(con); stamp=now_iso()
                cur=con.execute(
                    """INSERT INTO sales(invoice_no,customer_id,sale_date,subtotal,discount,tax,total,
                       payment_method,channel,notes,created_at) VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                    (invoice,customer_id,stamp,subtotal,discount,total_tax,total,payment,channel,
                     request.form.get("notes",""),stamp)
                )
                sale_id=cur.lastrowid
                for p,qty,line in line_items:
                    line_discount=discount*(line/subtotal) if subtotal else 0
                    tax=(line-line_discount)*p["tax_rate"]/100
                    con.execute(
                        """INSERT INTO sale_lines(sale_id,product_id,product_name,quantity,unit_price,
                           cost_price,discount,tax_rate,line_total) VALUES(?,?,?,?,?,?,?,?,?)""",
                        (sale_id,p["id"],p["name"],qty,p["selling_price"],p["cost_price"],
                         line_discount,p["tax_rate"],line-line_discount+tax)
                    )
                    con.execute("UPDATE products SET stock=stock-? WHERE id=?",(qty,p["id"]))
                    record_movement(con,"product",p["id"],p["name"],"Sale", -qty,p["unit"],invoice)
                if customer_id:
                    points=int(total/100*float(setting("loyalty_points_per_100","1")))
                    con.execute("UPDATE customers SET total_spend=total_spend+?,points=points+? WHERE id=?",(total,points,customer_id))
            audit("CREATE","sale",sale_id,invoice)
            flash(f"Invoice {invoice} saved. Stock and linked recipe ingredients updated.","success")
            return redirect(url_for("invoice",sale_id=sale_id))
        except (ValueError,KeyError,sqlite3.IntegrityError) as exc:
            flash(str(exc),"error")
        return redirect(url_for("sales"))
    with db() as con:
        products=con.execute("SELECT * FROM products WHERE active=1 AND stock>0 ORDER BY name").fetchall()
        customers=con.execute("SELECT * FROM customers ORDER BY name").fetchall()
        rows=con.execute("SELECT * FROM sales ORDER BY id DESC LIMIT 25").fetchall()
    return render_template("sales.html",products=products,customers=customers,sales=rows)

@app.route("/invoice/<int:sale_id>")
@login_required
def invoice(sale_id):
    with db() as con:
        sale=con.execute(
            """SELECT s.*,c.name customer_name,c.phone customer_phone FROM sales s
               LEFT JOIN customers c ON c.id=s.customer_id WHERE s.id=?""",(sale_id,)
        ).fetchone()
        if not sale: abort(404)
        lines=con.execute("SELECT * FROM sale_lines WHERE sale_id=?",(sale_id,)).fetchall()
    return render_template("invoice.html",sale=sale,lines=lines)

@app.route("/expenses",methods=["GET","POST"])
@login_required
def expenses():
    if request.method=="POST":
        try:
            amount=parse_float(request.form,"amount")
            if amount<=0: raise ValueError("Expense must be greater than zero.")
            with db() as con:
                con.execute(
                    "INSERT INTO expenses(expense_date,category,description,amount,payment_method,recurring) VALUES(?,?,?,?,?,?)",
                    (request.form.get("expense_date") or date.today().isoformat(),request.form["category"],
                     request.form.get("description",""),amount,request.form.get("payment_method","Cash"),
                     int(request.form.get("recurring")=="on"))
                )
            flash("Expense recorded.","success")
        except (ValueError,KeyError) as exc: flash(str(exc),"error")
        return redirect(url_for("expenses"))
    with db() as con:
        rows=con.execute("SELECT * FROM expenses ORDER BY expense_date DESC,id DESC LIMIT 100").fetchall()
        total=con.execute("SELECT COALESCE(SUM(amount),0) FROM expenses WHERE strftime('%Y-%m',expense_date)=strftime('%Y-%m','now')").fetchone()[0]
    return render_template("expenses.html",expenses=rows,month_total=total)

@app.route("/festivals",methods=["GET","POST"])
@login_required
def festivals():
    if request.method=="POST":
        try:
            name=request.form["name"].strip(); event_date=request.form["event_date"]
            uplift=parse_float(request.form,"expected_uplift")
            prep=int(request.form.get("preparation_days") or 7)
            if not name or not event_date or prep<0: raise ValueError("Enter festival name, date and valid preparation days.")
            with db() as con:
                cur=con.execute(
                    """INSERT INTO festivals(name,event_date,end_date,category,expected_uplift,
                       preparation_days,notes) VALUES(?,?,?,?,?,?,?)""",
                    (name,event_date,request.form.get("end_date",""),request.form.get("category","Festival"),
                     uplift,prep,request.form.get("notes",""))
                )
            audit("CREATE","festival",cur.lastrowid,name)
            flash("Festival/event added to demand calendar.","success")
        except (ValueError,KeyError) as exc: flash(str(exc),"error")
        return redirect(url_for("festivals"))
    with db() as con:
        rows=con.execute("SELECT * FROM festivals ORDER BY event_date").fetchall()
    return render_template("festivals.html",festivals=rows)

@app.route("/festivals/seed",methods=["POST"])
@login_required
def seed_festivals():
    # Dates are intentionally approximate planning prompts. Verify local dates annually.
    year=int(request.form.get("year",date.today().year))
    seeds=[
        ("Makar Sankranti",f"{year}-01-14","National festival",25,5),
        ("Holi",f"{year}-03-04","Festival",45,7),
        ("Ram Navami",f"{year}-03-26","Festival",20,4),
        ("Raksha Bandhan",f"{year}-08-28","Festival",55,10),
        ("Janmashtami",f"{year}-09-04","Festival",35,7),
        ("Ganesh Chaturthi",f"{year}-09-14","Festival",40,8),
        ("Navratri start",f"{year}-10-11","Festival",35,10),
        ("Dussehra",f"{year}-10-20","Festival",35,7),
        ("Diwali",f"{year}-11-08","Major sales period",100,21),
        ("Bhai Dooj",f"{year}-11-10","Festival",35,5),
        ("Christmas",f"{year}-12-25","Seasonal",20,7),
        ("New Year",f"{year}-12-31","Seasonal",25,7),
    ]
    with db() as con:
        for name,dt,cat,uplift,prep in seeds:
            con.execute(
                """INSERT INTO festivals(name,event_date,category,expected_uplift,preparation_days)
                   SELECT ?,?,?,?,? WHERE NOT EXISTS(SELECT 1 FROM festivals WHERE name=? AND event_date=?)""",
                (name,dt,cat,uplift,prep,name,dt)
            )
    flash("Planning suggestions added. Verify every festival date against the official local calendar before relying on it.","success")
    return redirect(url_for("festivals"))

@app.route("/daily-context",methods=["GET","POST"])
@login_required
def daily_context():
    if request.method=="POST":
        try:
            day=request.form["context_date"]
            footfall=parse_float(request.form,"footfall_index")
            with db() as con:
                con.execute(
                    """INSERT INTO daily_context(context_date,weekday_type,weather,temperature,rainfall_mm,
                       local_event,footfall_index,notes) VALUES(?,?,?,?,?,?,?,?)
                       ON CONFLICT(context_date) DO UPDATE SET weekday_type=excluded.weekday_type,
                       weather=excluded.weather,temperature=excluded.temperature,rainfall_mm=excluded.rainfall_mm,
                       local_event=excluded.local_event,footfall_index=excluded.footfall_index,notes=excluded.notes""",
                    (day,request.form.get("weekday_type","Normal"),request.form.get("weather","Unknown"),
                     float(request.form["temperature"]) if request.form.get("temperature") else None,
                     float(request.form["rainfall_mm"]) if request.form.get("rainfall_mm") else None,
                     request.form.get("local_event",""),footfall,request.form.get("notes",""))
                )
            flash("Daily context saved.","success")
        except (ValueError,KeyError) as exc: flash(str(exc),"error")
        return redirect(url_for("daily_context"))
    with db() as con:
        rows=con.execute("SELECT * FROM daily_context ORDER BY context_date DESC LIMIT 60").fetchall()
    return render_template("daily_context.html",contexts=rows)

@app.route("/forecast")
@login_required
def forecast():
    horizon=max(7,min(60,int(request.args.get("days",setting("forecast_horizon","14")))))
    product_id=request.args.get("product_id",type=int)
    with db() as con:
        products=con.execute("SELECT * FROM products WHERE active=1 ORDER BY name").fetchall()
        if not product_id and products: product_id=products[0]["id"]
        p=con.execute("SELECT * FROM products WHERE id=?",(product_id,)).fetchone() if product_id else None
        history=[]
        if p:
            history=con.execute(
                """SELECT date(s.sale_date) day,SUM(sl.quantity) qty
                   FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id
                   WHERE sl.product_id=? AND date(s.sale_date)>=date('now','-84 days')
                   GROUP BY date(s.sale_date) ORDER BY day""",(product_id,)
            ).fetchall()
        festivals=con.execute(
            "SELECT * FROM festivals WHERE active=1 AND date(event_date) BETWEEN date('now') AND date('now',?)",
            (f"+{horizon} days",)
        ).fetchall()
    # Explainable baseline: weighted recent daily average; this is a planning estimate, not an ML guarantee.
    by_day={r["day"]:float(r["qty"]) for r in history}
    recent_values=[by_day.get((date.today()-timedelta(days=i)).isoformat(),0) for i in range(1,29)]
    weighted=sum(v*(29-i) for i,v in enumerate(recent_values,1))/sum(range(1,29))
    weekday_values=defaultdict(list)
    for day,qty in by_day.items():
        weekday_values[date.fromisoformat(day).weekday()].append(qty)
    forecasts=[]
    for offset in range(1,horizon+1):
        d=date.today()+timedelta(days=offset)
        weekday=weekday_values.get(d.weekday(),[])
        weekday_avg=sum(weekday)/len(weekday) if weekday else weighted
        baseline=(weighted*0.55)+(weekday_avg*0.45)
        event=next((f for f in festivals if f["event_date"]==d.isoformat()),None)
        uplift=(float(event["expected_uplift"])/100) if event else 0
        context=None
        # User-entered footfall index is a transparent adjustment; 1.0 means neutral.
        with db() as con:
            context=con.execute("SELECT footfall_index FROM daily_context WHERE context_date=?",(d.isoformat(),)).fetchone()
        footfall=float(context["footfall_index"]) if context else 1.0
        estimate=max(0,baseline*(1+uplift)*footfall)
        forecasts.append({"date":d,"base":baseline,"uplift":uplift*100,"footfall":footfall,
                          "event":event["name"] if event else "", "estimate":estimate})
    history_total=sum(by_day.values())
    return render_template("forecast.html",products=products,product=p,horizon=horizon,
                           forecasts=forecasts,history_days=len(by_day),history_total=history_total,
                           weighted=weighted)

@app.route("/production",methods=["GET","POST"])
@login_required
def production():
    if request.method=="POST":
        try:
            pid=int(request.form["product_id"]); qty=parse_float(request.form,"planned_quantity")
            if qty<=0: raise ValueError("Planned quantity must be positive.")
            with db() as con:
                cur=con.execute(
                    """INSERT INTO production_batches(product_id,planned_date,planned_quantity,notes,created_at)
                       VALUES(?,?,?,?,?)""",
                    (pid,request.form.get("planned_date") or date.today().isoformat(),qty,
                     request.form.get("notes",""),now_iso())
                )
            audit("CREATE","production_batch",cur.lastrowid)
            flash("Production plan created.","success")
        except (ValueError,KeyError) as exc: flash(str(exc),"error")
        return redirect(url_for("production"))
    with db() as con:
        products=con.execute("SELECT * FROM products WHERE active=1 ORDER BY name").fetchall()
        batches=con.execute(
            """SELECT b.*,p.name product,p.unit FROM production_batches b
               JOIN products p ON p.id=b.product_id ORDER BY b.planned_date DESC LIMIT 100"""
        ).fetchall()
    return render_template("production.html",products=products,batches=batches)

@app.route("/production/<int:batch_id>/complete",methods=["POST"])
@login_required
def production_complete(batch_id):
    try:
        actual=parse_float(request.form,"actual_quantity")
        with db() as con:
            batch=con.execute("SELECT * FROM production_batches WHERE id=?",(batch_id,)).fetchone()
            if not batch: abort(404)
            if batch["status"]=="Completed": raise ValueError("Batch already completed.")
            recipe=con.execute(
                """SELECT r.quantity,i.id ingredient_id,i.name,i.unit,i.stock
                   FROM recipes r JOIN ingredients i ON i.id=r.ingredient_id WHERE r.product_id=?""",
                (batch["product_id"],)
            ).fetchall()
            for r in recipe:
                used=actual*r["quantity"]
                if used>r["stock"]: raise ValueError(f"Insufficient ingredient: {r['name']}.")
            for r in recipe:
                used=actual*r["quantity"]
                con.execute("UPDATE ingredients SET stock=stock-? WHERE id=?",(used,r["ingredient_id"]))
                record_movement(con,"ingredient",r["ingredient_id"],r["name"],"Production consumption",-used,r["unit"],f"BATCH-{batch_id}")
            con.execute("UPDATE products SET stock=stock+? WHERE id=?",(actual,batch["product_id"]))
            p=con.execute("SELECT name,unit FROM products WHERE id=?",(batch["product_id"],)).fetchone()
            record_movement(con,"product",batch["product_id"],p["name"],"Production output",actual,p["unit"],f"BATCH-{batch_id}")
            con.execute("UPDATE production_batches SET actual_quantity=?,status='Completed' WHERE id=?",(actual,batch_id))
        flash("Production completed; ingredients consumed and finished stock increased.","success")
    except (ValueError,KeyError) as exc: flash(str(exc),"error")
    return redirect(url_for("production"))

@app.route("/expiry")
@login_required
def expiry():
    with db() as con:
        rows=con.execute(
            """SELECT l.*,p.name,p.unit FROM stock_lots l JOIN products p ON p.id=l.product_id
               ORDER BY CASE WHEN expiry_date='' THEN 1 ELSE 0 END,expiry_date LIMIT 200"""
        ).fetchall()
    return render_template("expiry.html",lots=rows)

@app.route("/reports")
@login_required
def reports():
    start=request.args.get("start",date.today().replace(day=1).isoformat())
    end=request.args.get("end",date.today().isoformat())
    with db() as con:
        summary=con.execute(
            """SELECT COALESCE(SUM(total),0) revenue,COALESCE(SUM(discount),0) discounts,
               COALESCE(SUM(tax),0) tax,COUNT(*) invoices FROM sales WHERE date(sale_date) BETWEEN ? AND ?""",
            (start,end)
        ).fetchone()
        costs=con.execute(
            """SELECT COALESCE(SUM(sl.quantity*sl.cost_price),0) cost FROM sale_lines sl
               JOIN sales s ON s.id=sl.sale_id WHERE date(s.sale_date) BETWEEN ? AND ?""",(start,end)
        ).fetchone()["cost"]
        expense=con.execute("SELECT COALESCE(SUM(amount),0) amount FROM expenses WHERE date(expense_date) BETWEEN ? AND ?",(start,end)).fetchone()["amount"]
        daily=con.execute(
            """SELECT date(sale_date) day,COUNT(*) invoices,SUM(total) revenue
               FROM sales WHERE date(sale_date) BETWEEN ? AND ? GROUP BY date(sale_date) ORDER BY day DESC""",
            (start,end)
        ).fetchall()
        best=con.execute(
            """SELECT product_name,SUM(quantity) qty,SUM(line_total) revenue
               FROM sale_lines sl JOIN sales s ON s.id=sl.sale_id
               WHERE date(s.sale_date) BETWEEN ? AND ? GROUP BY product_id ORDER BY qty DESC LIMIT 15""",
            (start,end)
        ).fetchall()
    return render_template("reports.html",start=start,end=end,summary=summary,costs=costs,
                           expense=expense,gross_profit=float(summary["revenue"])-float(costs),
                           estimated_net=float(summary["revenue"])-float(costs)-float(expense),
                           daily=daily,best=best)

@app.route("/settings",methods=["GET","POST"])
@login_required
def settings():
    keys=["shop_name","shop_city","gstin","phone","address","loyalty_points_per_100","forecast_horizon","default_tax_rate"]
    if request.method=="POST":
        with db() as con:
            for key in keys:
                con.execute("INSERT INTO settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                            (key,request.form.get(key,"").strip()))
        flash("Shop settings saved.","success")
        return redirect(url_for("settings"))
    return render_template("settings.html",settings={k:setting(k) for k in keys})

@app.route("/import/products",methods=["GET","POST"])
@login_required
def import_products():
    if request.method=="POST":
        file=request.files.get("file")
        if not file or not file.filename.lower().endswith(".csv"):
            flash("Choose a CSV file.","error");return redirect(url_for("import_products"))
        try:
            text=file.stream.read().decode("utf-8-sig")
            reader=csv.DictReader(io.StringIO(text))
            required={"name","category","unit","selling_price","opening_stock","reorder_level"}
            if not reader.fieldnames or not required.issubset(set(reader.fieldnames)):
                raise ValueError("CSV must include: "+", ".join(sorted(required)))
            count=0
            with db() as con:
                cat_map={r["name"].lower():r["id"] for r in con.execute("SELECT * FROM categories")}
                for row in reader:
                    name=(row.get("name") or "").strip()
                    if not name: continue
                    cat=(row.get("category") or "Other").strip()
                    if cat.lower() not in cat_map:
                        cur=con.execute("INSERT INTO categories(name) VALUES(?)",(cat,))
                        cat_map[cat.lower()]=cur.lastrowid
                    stock=float(row.get("opening_stock") or 0)
                    cur=con.execute(
                        """INSERT INTO products(sku,name,category_id,unit,selling_price,cost_price,
                           tax_rate,stock,reorder_level,target_stock,created_at)
                           VALUES(?,?,?,?,?,?,?,?,?,?,?)""",
                        ((row.get("sku") or "").strip() or None,name,cat_map[cat.lower()],
                         (row.get("unit") or "kg").strip(),float(row["selling_price"]),
                         float(row.get("cost_price") or 0),float(row.get("tax_rate") or 0),stock,
                         float(row["reorder_level"]),float(row.get("target_stock") or 0),now_iso())
                    )
                    if stock: record_movement(con,"product",cur.lastrowid,name,"Opening stock",stock,row.get("unit") or "kg","CSV import")
                    count+=1
            flash(f"Imported {count} products.","success")
        except Exception as exc: flash(f"Import stopped: {exc}","error")
        return redirect(url_for("products"))
    return render_template("import_products.html")

@app.route("/export/<kind>.csv")
@login_required
def export_csv(kind):
    queries={
        "products":("SELECT sku,name,category_id,unit,selling_price,cost_price,tax_rate,stock,reorder_level,target_stock FROM products WHERE active=1",
                    ["sku","name","category_id","unit","selling_price","cost_price","tax_rate","opening_stock","reorder_level","target_stock"]),
        "sales":("SELECT s.invoice_no,s.sale_date,s.subtotal,s.discount,s.tax,s.total,s.payment_method,s.channel,sl.product_name,sl.quantity,sl.unit_price FROM sales s JOIN sale_lines sl ON sl.sale_id=s.id ORDER BY s.sale_date",
                 ["invoice_no","sale_date","subtotal","discount","tax","total","payment_method","channel","product","quantity","unit_price"]),
        "customers":("SELECT customer_code,name,phone,email,birthday,address,points,total_spend FROM customers",
                     ["customer_code","name","phone","email","birthday","address","points","total_spend"]),
    }
    if kind not in queries: abort(404)
    sql,headers=queries[kind]
    with db() as con: rows=con.execute(sql).fetchall()
    output=io.StringIO();writer=csv.writer(output);writer.writerow(headers)
    writer.writerows([tuple(r) for r in rows])
    return Response("\ufeff"+output.getvalue(),mimetype="text/csv",
                    headers={"Content-Disposition":f"attachment; filename=new_bharat_sweets_{kind}.csv"})

@app.route("/backup")
@login_required
def backup():
    if not DB_PATH.exists(): abort(404)
    return send_file(DB_PATH,as_attachment=True,download_name=f"new_bharat_sweets_backup_{date.today().isoformat()}.db")

@app.route("/health")
def health():
    return jsonify(status="ok",application="New Bharat Sweets Enterprise")

@app.errorhandler(400)
def bad_request(error):
    return render_template("error.html",code=400,message="The request could not be processed. Refresh the page and try again."),400

@app.errorhandler(404)
def not_found(error):
    return render_template("error.html",code=404,message="The requested page or record was not found."),404

if __name__=="__main__":
    app.run(host="0.0.0.0",port=int(os.environ.get("PORT",5000)),debug=False)
