"""Transparent demand-planning helpers.

These functions are intentionally explainable baselines, not claims of accurate
machine learning. Validate forecasts against real shop history before using them
for purchasing, production or staffing decisions.
"""
from collections import defaultdict
from datetime import date, timedelta
from statistics import mean
from typing import Mapping, Sequence


def date_range(start: date, days: int):
    if days < 0:
        raise ValueError("Days cannot be negative.")
    for offset in range(days):
        yield start + timedelta(days=offset)


def recency_weighted_mean(values: Sequence[float], newest_first: bool = True) -> float:
    if not values:
        return 0.0
    clean = [max(0.0, float(v)) for v in values]
    if not newest_first:
        clean.reverse()
    weights = list(range(len(clean), 0, -1))
    return sum(v*w for v,w in zip(clean,weights)) / sum(weights)


def weekday_profile(daily_sales: Mapping[date, float]) -> dict:
    groups = defaultdict(list)
    for day, quantity in daily_sales.items():
        groups[day.weekday()].append(max(0.0, float(quantity)))
    return {weekday: mean(values) for weekday, values in groups.items() if values}


def calculate_baseline(daily_sales: Mapping[date, float], target_day: date,
                       recent_days: int = 28, weekday_weight: float = 0.45) -> dict:
    if not 0 <= weekday_weight <= 1:
        raise ValueError("Weekday weight must be between zero and one.")
    recent = []
    for offset in range(1, recent_days + 1):
        recent.append(float(daily_sales.get(target_day - timedelta(days=offset), 0)))
    weighted = recency_weighted_mean(recent)
    profile = weekday_profile(daily_sales)
    weekday_avg = profile.get(target_day.weekday(), weighted)
    estimate = weighted * (1-weekday_weight) + weekday_avg * weekday_weight
    return {
        "estimate": max(0.0, estimate),
        "weighted_recent_average": weighted,
        "weekday_average": weekday_avg,
        "weekday": target_day.weekday(),
        "history_points": len(daily_sales),
    }


def apply_context(base: float, festival_uplift_percent: float = 0.0,
                  footfall_index: float = 1.0, weather_factor: float = 1.0) -> float:
    values = [base, festival_uplift_percent, footfall_index, weather_factor]
    if any(float(value) < 0 for value in values):
        raise ValueError("Forecast adjustments cannot be negative.")
    return max(0.0, float(base) * (1 + float(festival_uplift_percent)/100)
               * float(footfall_index) * float(weather_factor))


def forecast_horizon(daily_sales: Mapping[date, float], start: date,
                     days: int, events: Mapping[date, float] | None = None,
                     footfall: Mapping[date, float] | None = None) -> list:
    if days < 1 or days > 180:
        raise ValueError("Forecast horizon must be between 1 and 180 days.")
    events = events or {}
    footfall = footfall or {}
    output = []
    for target in date_range(start, days):
        baseline = calculate_baseline(daily_sales, target)
        uplift = float(events.get(target, 0))
        index = float(footfall.get(target, 1.0))
        output.append({
            "date": target,
            "base": baseline["estimate"],
            "festival_uplift_percent": uplift,
            "footfall_index": index,
            "forecast": apply_context(baseline["estimate"], uplift, index),
            "method": "recency-weighted + weekday profile",
        })
    return output


def forecast_error(actual: Sequence[float], predicted: Sequence[float]) -> dict:
    if len(actual) != len(predicted):
        raise ValueError("Actual and predicted series must have equal length.")
    if not actual:
        return {"mae": None, "mape": None, "bias": None}
    errors = [float(p)-float(a) for a,p in zip(actual,predicted)]
    mae = sum(abs(e) for e in errors)/len(errors)
    nonzero = [(abs(float(a)-float(p))/abs(float(a))*100)
               for a,p in zip(actual,predicted) if float(a) != 0]
    mape = sum(nonzero)/len(nonzero) if nonzero else None
    return {"mae": mae, "mape": mape, "bias": sum(errors)/len(errors)}


def classify_forecast_quality(history_days: int) -> str:
    if history_days < 14:
        return "insufficient"
    if history_days < 56:
        return "early"
    if history_days < 84:
        return "developing"
    return "more_stable_but_validate"


def moving_average(values: Sequence[float], window: int = 7) -> float:
    if window < 1:
        raise ValueError("Window must be at least one.")
    if not values:
        return 0.0
    subset = list(values)[-window:]
    return sum(max(0.0,float(v)) for v in subset)/len(subset)


def seasonal_index(observed: Sequence[float], overall_average: float) -> float:
    if overall_average <= 0:
        return 1.0
    return max(0.0, mean(observed)/overall_average) if observed else 1.0
