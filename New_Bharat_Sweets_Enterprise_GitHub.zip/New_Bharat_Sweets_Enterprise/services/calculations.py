"""Financial and commercial calculations used by shop operations.

All monetary values are represented as Python floats in this starter application.
For audited financial ledgers, use Decimal and a formal accounting workflow.
"""
from dataclasses import dataclass
from typing import Iterable, Sequence


@dataclass(frozen=True)
class InvoiceLineInput:
    quantity: float
    unit_price: float
    tax_rate: float = 0.0
    unit_cost: float = 0.0


@dataclass(frozen=True)
class InvoiceLineResult:
    gross: float
    allocated_discount: float
    taxable_value: float
    tax_amount: float
    line_total: float
    estimated_cost: float
    estimated_margin: float


@dataclass(frozen=True)
class InvoiceResult:
    subtotal: float
    discount: float
    taxable_value: float
    tax: float
    total: float
    cost: float
    gross_profit_estimate: float
    margin_percent_estimate: float
    lines: tuple


def validate_non_negative(value: float, label: str = "Value") -> float:
    number = float(value)
    if number < 0:
        raise ValueError(f"{label} cannot be negative.")
    return number


def validate_positive(value: float, label: str = "Quantity") -> float:
    number = float(value)
    if number <= 0:
        raise ValueError(f"{label} must be greater than zero.")
    return number


def weighted_discount(gross_lines: Sequence[float], discount: float) -> list:
    """Allocate an invoice-level discount proportionally to line gross values."""
    discount = validate_non_negative(discount, "Discount")
    subtotal = sum(validate_non_negative(x, "Line amount") for x in gross_lines)
    if discount > subtotal:
        raise ValueError("Discount cannot exceed invoice subtotal.")
    if subtotal == 0:
        return [0.0 for _ in gross_lines]
    allocations = [discount * (float(line) / subtotal) for line in gross_lines]
    # Correct floating point residue on the final line so allocations sum exactly.
    if allocations:
        allocations[-1] += discount - sum(allocations)
    return allocations


def calculate_invoice(lines: Iterable[InvoiceLineInput], invoice_discount: float = 0.0) -> InvoiceResult:
    """Calculate line tax after proportional discount allocation."""
    prepared = list(lines)
    if not prepared:
        raise ValueError("An invoice needs at least one line.")
    gross_values = []
    for line in prepared:
        quantity = validate_positive(line.quantity)
        price = validate_non_negative(line.unit_price, "Unit price")
        validate_non_negative(line.tax_rate, "Tax rate")
        validate_non_negative(line.unit_cost, "Unit cost")
        gross_values.append(quantity * price)
    subtotal = sum(gross_values)
    allocations = weighted_discount(gross_values, invoice_discount)
    results = []
    total_tax = 0.0
    total_cost = 0.0
    for line, gross, allocation in zip(prepared, gross_values, allocations):
        taxable = gross - allocation
        tax = taxable * float(line.tax_rate) / 100.0
        cost = float(line.quantity) * float(line.unit_cost)
        total_tax += tax
        total_cost += cost
        results.append(InvoiceLineResult(
            gross=gross,
            allocated_discount=allocation,
            taxable_value=taxable,
            tax_amount=tax,
            line_total=taxable + tax,
            estimated_cost=cost,
            estimated_margin=taxable - cost,
        ))
    total = subtotal - float(invoice_discount) + total_tax
    gross_profit = subtotal - float(invoice_discount) - total_cost
    margin = (gross_profit / (subtotal - float(invoice_discount)) * 100.0
              if subtotal > float(invoice_discount) else 0.0)
    return InvoiceResult(
        subtotal=subtotal,
        discount=float(invoice_discount),
        taxable_value=subtotal - float(invoice_discount),
        tax=total_tax,
        total=total,
        cost=total_cost,
        gross_profit_estimate=gross_profit,
        margin_percent_estimate=margin,
        lines=tuple(results),
    )


def contribution_margin(selling_price: float, variable_cost: float) -> float:
    return validate_non_negative(selling_price, "Selling price") - validate_non_negative(variable_cost, "Variable cost")


def contribution_margin_percent(selling_price: float, variable_cost: float) -> float:
    price = validate_non_negative(selling_price, "Selling price")
    if price == 0:
        return 0.0
    return contribution_margin(price, variable_cost) / price * 100.0


def break_even_units(fixed_cost: float, selling_price: float, variable_cost: float) -> float:
    fixed = validate_non_negative(fixed_cost, "Fixed cost")
    contribution = contribution_margin(selling_price, variable_cost)
    if contribution <= 0:
        raise ValueError("Break-even cannot be calculated when contribution per unit is zero or negative.")
    return fixed / contribution


def reorder_quantity(current_stock: float, target_stock: float, committed_stock: float = 0.0) -> float:
    current = validate_non_negative(current_stock, "Current stock")
    target = validate_non_negative(target_stock, "Target stock")
    committed = validate_non_negative(committed_stock, "Committed stock")
    return max(0.0, target - current + committed)


def safety_stock(average_daily_demand: float, lead_time_days: float, buffer_days: float) -> float:
    demand = validate_non_negative(average_daily_demand, "Average daily demand")
    lead = validate_non_negative(lead_time_days, "Lead time")
    buffer = validate_non_negative(buffer_days, "Buffer days")
    return demand * (lead + buffer)


def stock_cover_days(current_stock: float, average_daily_demand: float) -> float | None:
    stock = validate_non_negative(current_stock, "Current stock")
    demand = validate_non_negative(average_daily_demand, "Average daily demand")
    if demand == 0:
        return None
    return stock / demand


def percentage_change(current: float, previous: float) -> float | None:
    if float(previous) == 0:
        return None
    return (float(current) - float(previous)) / abs(float(previous)) * 100.0


def weighted_average(values: Sequence[float], weights: Sequence[float]) -> float:
    if len(values) != len(weights):
        raise ValueError("Values and weights must have the same length.")
    if not values:
        return 0.0
    if any(float(w) < 0 for w in weights):
        raise ValueError("Weights cannot be negative.")
    denominator = sum(weights)
    if denominator == 0:
        return 0.0
    return sum(float(v) * float(w) for v, w in zip(values, weights)) / denominator


def festival_adjusted_demand(base_demand: float, uplift_percent: float, footfall_index: float = 1.0) -> float:
    base = validate_non_negative(base_demand, "Base demand")
    uplift = validate_non_negative(uplift_percent, "Festival uplift")
    footfall = validate_non_negative(footfall_index, "Footfall index")
    return base * (1.0 + uplift / 100.0) * footfall


def production_requirement(forecast_demand: float, finished_stock: float, buffer_units: float = 0.0) -> float:
    demand = validate_non_negative(forecast_demand, "Forecast demand")
    stock = validate_non_negative(finished_stock, "Finished stock")
    buffer = validate_non_negative(buffer_units, "Buffer")
    return max(0.0, demand + buffer - stock)


def ingredient_requirement(product_units: float, ingredient_per_unit: float) -> float:
    units = validate_non_negative(product_units, "Product units")
    recipe = validate_non_negative(ingredient_per_unit, "Recipe quantity")
    return units * recipe


def ingredient_cost(quantity: float, cost_per_unit: float) -> float:
    return validate_non_negative(quantity, "Quantity") * validate_non_negative(cost_per_unit, "Cost per unit")


def price_from_cost(cost: float, target_margin_percent: float) -> float:
    base = validate_non_negative(cost, "Cost")
    margin = validate_non_negative(target_margin_percent, "Target margin")
    if margin >= 100:
        raise ValueError("Target margin must be below 100%.")
    return base / (1.0 - margin / 100.0)


def discount_price(price: float, discount_percent: float) -> float:
    base = validate_non_negative(price, "Price")
    discount = validate_non_negative(discount_percent, "Discount")
    if discount > 100:
        raise ValueError("Discount cannot exceed 100%.")
    return base * (1.0 - discount / 100.0)


def effective_tax_amount(taxable_value: float, tax_rate: float) -> float:
    return validate_non_negative(taxable_value, "Taxable value") * validate_non_negative(tax_rate, "Tax rate") / 100.0
