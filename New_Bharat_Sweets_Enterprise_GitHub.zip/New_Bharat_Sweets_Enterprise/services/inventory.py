"""Inventory control calculations and validation helpers."""
from dataclasses import dataclass


@dataclass(frozen=True)
class ReorderDecision:
    current_stock: float
    reorder_point: float
    target_stock: float
    suggested_order: float
    days_of_cover: float | None
    urgency: str


def nonnegative(value, label):
    result=float(value)
    if result<0:
        raise ValueError(f"{label} cannot be negative.")
    return result


def reorder_point(average_daily_demand, lead_time_days, safety_days=0):
    demand=nonnegative(average_daily_demand,"Demand")
    lead=nonnegative(lead_time_days,"Lead time")
    buffer=nonnegative(safety_days,"Safety days")
    return demand*(lead+buffer)


def decide_reorder(current_stock, average_daily_demand, lead_time_days,
                   target_days_cover=14, safety_days=2):
    stock=nonnegative(current_stock,"Stock")
    demand=nonnegative(average_daily_demand,"Demand")
    lead=nonnegative(lead_time_days,"Lead time")
    safety=nonnegative(safety_days,"Safety days")
    cover=stock/demand if demand else None
    point=reorder_point(demand,lead,safety)
    target=demand*(lead+target_days_cover+safety)
    suggested=max(0.0,target-stock)
    if stock<=point:
        urgency="reorder_now"
    elif cover is not None and cover<=lead+safety:
        urgency="urgent"
    elif cover is not None and cover<=lead+target_days_cover:
        urgency="watch"
    else:
        urgency="healthy"
    return ReorderDecision(stock,point,target,suggested,cover,urgency)


def apply_stock_movement(current_stock, movement):
    current=nonnegative(current_stock,"Current stock")
    updated=current+float(movement)
    if updated<0:
        raise ValueError("Stock movement would make the balance negative.")
    return updated


def aggregate_demand_by_sku(lines):
    totals={}
    for sku,qty in lines:
        quantity=nonnegative(qty,"Quantity")
        totals[sku]=totals.get(sku,0.0)+quantity
    return totals


def stock_variance(system_quantity, counted_quantity):
    system=nonnegative(system_quantity,"System quantity")
    counted=nonnegative(counted_quantity,"Counted quantity")
    return counted-system


def shrinkage_percent(system_quantity, counted_quantity):
    system=nonnegative(system_quantity,"System quantity")
    if system==0:
        return 0.0
    loss=max(0.0,system-nonnegative(counted_quantity,"Counted quantity"))
    return loss/system*100.0


def expiry_status(days_to_expiry):
    days=int(days_to_expiry)
    if days<0:
        return "expired"
    if days==0:
        return "expires_today"
    if days<=3:
        return "critical"
    if days<=7:
        return "soon"
    return "in_date"


def lot_remaining(received, sold, wasted):
    received=nonnegative(received,"Received")
    sold=nonnegative(sold,"Sold")
    wasted=nonnegative(wasted,"Wasted")
    remaining=received-sold-wasted
    if remaining<0:
        raise ValueError("Lot movements exceed received quantity.")
    return remaining


def stock_turnover(cost_of_goods_sold, average_inventory_value):
    cogs=nonnegative(cost_of_goods_sold,"Cost of goods sold")
    inventory=nonnegative(average_inventory_value,"Average inventory")
    if inventory==0:
        return None
    return cogs/inventory


def days_inventory_on_hand(average_inventory_value, daily_cogs):
    inventory=nonnegative(average_inventory_value,"Average inventory")
    daily=nonnegative(daily_cogs,"Daily cost of goods sold")
    if daily==0:
        return None
    return inventory/daily
