import unittest
from datetime import date, timedelta

from services.calculations import (
    InvoiceLineInput, calculate_invoice, weighted_discount,
    contribution_margin, contribution_margin_percent, break_even_units,
    reorder_quantity, safety_stock, stock_cover_days, percentage_change,
    weighted_average, festival_adjusted_demand, production_requirement,
    ingredient_requirement, ingredient_cost, price_from_cost,
    discount_price, effective_tax_amount,
)
from services.forecasting import (
    recency_weighted_mean, weekday_profile, calculate_baseline,
    apply_context, forecast_horizon, forecast_error,
    classify_forecast_quality, moving_average, seasonal_index,
)
from services.inventory import (
    reorder_point, decide_reorder, apply_stock_movement,
    aggregate_demand_by_sku, stock_variance, shrinkage_percent,
    expiry_status, lot_remaining, stock_turnover, days_inventory_on_hand,
)


class InvoiceCalculationTests(unittest.TestCase):
    def test_invoice_basic(self):
        result=calculate_invoice([InvoiceLineInput(2,100,5,60)])
        self.assertAlmostEqual(result.subtotal,200)
        self.assertAlmostEqual(result.tax,10)
        self.assertAlmostEqual(result.total,210)
        self.assertAlmostEqual(result.cost,120)
        self.assertAlmostEqual(result.gross_profit_estimate,80)

    def test_invoice_proportional_discount(self):
        result=calculate_invoice([
            InvoiceLineInput(1,100,5,50),
            InvoiceLineInput(1,300,12,100),
        ],40)
        self.assertAlmostEqual(result.subtotal,400)
        self.assertAlmostEqual(result.taxable_value,360)
        self.assertAlmostEqual(result.lines[0].allocated_discount,10)
        self.assertAlmostEqual(result.lines[1].allocated_discount,30)
        self.assertAlmostEqual(result.tax,4.5+32.4)

    def test_invoice_rejects_empty(self):
        with self.assertRaises(ValueError):
            calculate_invoice([])

    def test_invoice_rejects_discount_over_subtotal(self):
        with self.assertRaises(ValueError):
            calculate_invoice([InvoiceLineInput(1,50)],51)

    def test_invoice_rejects_negative_quantity(self):
        with self.assertRaises(ValueError):
            calculate_invoice([InvoiceLineInput(-1,50)])

    def test_invoice_rejects_negative_tax(self):
        with self.assertRaises(ValueError):
            calculate_invoice([InvoiceLineInput(1,50,-1)])

    def test_discount_allocation_sums_exactly(self):
        allocations=weighted_discount([19.99,24.50,88.25],13.17)
        self.assertAlmostEqual(sum(allocations),13.17)

    def test_zero_subtotal_discount_allocation(self):
        self.assertEqual(weighted_discount([0,0],0),[0,0])

    def test_contribution_margin(self):
        self.assertEqual(contribution_margin(100,65),35)
        self.assertAlmostEqual(contribution_margin_percent(100,65),35)

    def test_break_even(self):
        self.assertAlmostEqual(break_even_units(1000,100,60),25)

    def test_break_even_rejects_negative_contribution(self):
        with self.assertRaises(ValueError):
            break_even_units(1000,50,60)

    def test_reorder_quantity(self):
        self.assertEqual(reorder_quantity(12,40),28)
        self.assertEqual(reorder_quantity(50,40),0)

    def test_safety_stock(self):
        self.assertEqual(safety_stock(5,3,2),25)

    def test_stock_cover(self):
        self.assertEqual(stock_cover_days(20,5),4)
        self.assertIsNone(stock_cover_days(20,0))

    def test_percentage_change(self):
        self.assertEqual(percentage_change(120,100),20)
        self.assertIsNone(percentage_change(10,0))

    def test_weighted_average(self):
        self.assertAlmostEqual(weighted_average([10,20],[1,3]),17.5)

    def test_weighted_average_length_mismatch(self):
        with self.assertRaises(ValueError):
            weighted_average([1,2],[1])

    def test_festival_uplift(self):
        self.assertAlmostEqual(festival_adjusted_demand(100,25,1.2),150)

    def test_production_requirement(self):
        self.assertEqual(production_requirement(80,25,5),60)

    def test_ingredient_requirement(self):
        self.assertAlmostEqual(ingredient_requirement(12,.125),1.5)

    def test_ingredient_cost(self):
        self.assertEqual(ingredient_cost(2,80),160)

    def test_price_from_cost(self):
        self.assertEqual(price_from_cost(80,20),100)

    def test_price_from_cost_rejects_full_margin(self):
        with self.assertRaises(ValueError):
            price_from_cost(80,100)

    def test_discount_price(self):
        self.assertEqual(discount_price(200,15),170)

    def test_tax_amount(self):
        self.assertEqual(effective_tax_amount(1000,5),50)


class ForecastingTests(unittest.TestCase):
    def test_recency_weighted_mean(self):
        self.assertGreater(recency_weighted_mean([10,20,30]),10)

    def test_recency_empty(self):
        self.assertEqual(recency_weighted_mean([]),0)

    def test_weekday_profile(self):
        monday=date(2026,10,26)
        profile=weekday_profile({monday:10,monday+timedelta(days=7):20})
        self.assertEqual(profile[0],15)

    def test_baseline_has_explainable_parts(self):
        target=date(2026,11,1)
        history={target-timedelta(days=i):float(i) for i in range(1,20)}
        result=calculate_baseline(history,target)
        self.assertIn("weighted_recent_average",result)
        self.assertGreaterEqual(result["estimate"],0)

    def test_baseline_weekday_weight_validation(self):
        with self.assertRaises(ValueError):
            calculate_baseline({},date.today(),weekday_weight=1.5)

    def test_context_multiplier(self):
        self.assertAlmostEqual(apply_context(100,30,1.1),143)

    def test_forecast_horizon_length(self):
        result=forecast_horizon({},date.today()+timedelta(days=1),14)
        self.assertEqual(len(result),14)

    def test_forecast_horizon_limit(self):
        with self.assertRaises(ValueError):
            forecast_horizon({},date.today(),200)

    def test_forecast_event_and_footfall(self):
        target=date.today()+timedelta(days=1)
        result=forecast_horizon({},target,1,{target:50},{target:1.2})
        self.assertGreaterEqual(result[0]["forecast"],0)

    def test_forecast_error(self):
        result=forecast_error([10,20],[12,18])
        self.assertEqual(result["mae"],2)
        self.assertEqual(result["bias"],0)

    def test_forecast_error_empty(self):
        self.assertIsNone(forecast_error([],[])["mae"])

    def test_forecast_error_length_mismatch(self):
        with self.assertRaises(ValueError):
            forecast_error([1],[1,2])

    def test_quality_bands(self):
        self.assertEqual(classify_forecast_quality(5),"insufficient")
        self.assertEqual(classify_forecast_quality(30),"early")
        self.assertEqual(classify_forecast_quality(70),"developing")
        self.assertEqual(classify_forecast_quality(100),"more_stable_but_validate")

    def test_moving_average(self):
        self.assertEqual(moving_average([1,2,3,4],2),3.5)

    def test_seasonal_index(self):
        self.assertEqual(seasonal_index([10,20],10),1.5)


class InventoryTests(unittest.TestCase):
    def test_reorder_point(self):
        self.assertEqual(reorder_point(5,4,2),30)

    def test_reorder_decision(self):
        decision=decide_reorder(10,5,4,target_days_cover=14,safety_days=2)
        self.assertEqual(decision.urgency,"reorder_now")
        self.assertGreater(decision.suggested_order,0)

    def test_healthy_reorder_decision(self):
        decision=decide_reorder(500,2,2)
        self.assertEqual(decision.urgency,"healthy")

    def test_stock_movement(self):
        self.assertEqual(apply_stock_movement(10,-3),7)

    def test_stock_movement_prevents_negative(self):
        with self.assertRaises(ValueError):
            apply_stock_movement(2,-3)

    def test_aggregate_sku_demand(self):
        result=aggregate_demand_by_sku([("A",2),("B",1),("A",3)])
        self.assertEqual(result,{"A":5,"B":1})

    def test_stock_variance(self):
        self.assertEqual(stock_variance(100,96),-4)

    def test_shrinkage(self):
        self.assertEqual(shrinkage_percent(100,95),5)

    def test_expiry_status(self):
        self.assertEqual(expiry_status(-1),"expired")
        self.assertEqual(expiry_status(0),"expires_today")
        self.assertEqual(expiry_status(2),"critical")
        self.assertEqual(expiry_status(6),"soon")
        self.assertEqual(expiry_status(30),"in_date")

    def test_lot_remaining(self):
        self.assertEqual(lot_remaining(100,30,5),65)

    def test_lot_movement_overdraw(self):
        with self.assertRaises(ValueError):
            lot_remaining(10,8,3)

    def test_stock_turnover(self):
        self.assertEqual(stock_turnover(1000,250),4)

    def test_stock_turnover_zero_inventory(self):
        self.assertIsNone(stock_turnover(100,0))

    def test_days_inventory(self):
        self.assertEqual(days_inventory_on_hand(500,25),20)


if __name__ == "__main__":
    unittest.main()
