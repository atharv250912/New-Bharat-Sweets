# New Bharat Sweets Enterprise — Operating Guide

## Initial configuration order

1. **Shop settings** — confirm shop name, city, phone, address, GSTIN and loyalty points policy.
2. **Categories** — review the default Sweets, Namkeen, Snacks, Beverages and Other categories.
3. **Products** — add every sellable item, exact unit, selling price, direct cost, applicable tax rate, opening quantity, reorder point and target quantity.
4. **Suppliers** — add regular ingredient, packaging and finished-product suppliers.
5. **Ingredients** — enter raw materials and their physical opening stock.
6. **Recipes** — add the quantity of each ingredient required per one finished product unit. Confirm units and production yield.
7. **Customers** — add only customers who have agreed to share their details.
8. **Festivals** — add the actual local event dates and a conservative expected uplift assumption.
9. **Daily context** — record market days, weather disruptions, school events, local fairs and unusual footfall.
10. **Sales and purchases** — enter every invoice and receipt consistently.

## Festival planning worksheet

For each festival or local event, decide:
- Start and end dates, verified for the relevant year and local observance.
- Which product families are likely to be affected.
- Whether gift boxes, bulk orders or special packaging are needed.
- How many preparation days are required.
- Whether suppliers can meet the ingredient and packaging requirement.
- What staffing and delivery capacity is required.
- What uplift assumption is justified by prior years or a conservative estimate.
- Actual sales after the event, so next year's assumption can be reviewed.

The app stores an event-level uplift assumption. It does not automatically infer product-specific festival demand. The forecast is a planning aid, not a promise of sales.

## Inventory controls

- Record opening stock from a physical count.
- Record every purchase when goods are received.
- Record every sale at the time it occurs.
- Complete production batches only after confirming actual output.
- Configure recipes in consistent units.
- Record wastage and stock-count corrections promptly.
- Compare system stock with physical stock regularly.
- Keep separate handling and food-safety procedures for perishable items.

## Sales and tax

The app calculates a simple line-level tax estimate from each product's configured tax rate, after proportionally allocating invoice discount. It is not a GST compliance engine. Confirm HSN classification, applicable rates, invoice wording, place-of-supply and reporting requirements with a qualified accountant before live use.

## Forecasting

The forecast baseline uses recent weighted sales and weekday averages. Festival uplift and footfall are manual multipliers. The result should be compared with actual sales. A few weeks of data are not enough to establish a reliable seasonal model. Capture clean daily sales and avoid entering artificial history.

## Backup and security

- Use a private GitHub repository.
- Set a strong `APP_PASSWORD` and unique `SECRET_KEY` in the hosting environment.
- Never upload the database, `.env` file or secrets to GitHub.
- Download a database backup regularly and store it separately.
- Test restoring a backup before relying on the app.
- Limit access to shop staff who need it.
- This starter uses a single owner password; it does not implement staff roles or detailed per-user permissions.

## Features not yet complete

Lot-by-lot expiry tracking, automated supplier purchase orders, barcode scanning, multi-user permissions, WhatsApp notifications, online payment integration, accounting exports and validated statistical / machine-learning forecasting are not fully implemented. Do not use a visible placeholder page as evidence that a feature is operational.
