document.addEventListener("DOMContentLoaded", () => {
  const token = document.querySelector('meta[name="csrf-token"]')?.content;
  if (token) document.querySelectorAll('form[method="post"],form[method="POST"]').forEach(form => {
    if (!form.querySelector('input[name="_csrf"]')) {
      const field=document.createElement("input");
      field.type="hidden";field.name="_csrf";field.value=token;form.appendChild(field);
    }
  });
});
